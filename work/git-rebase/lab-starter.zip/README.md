# 📘 Git Rebase Lab Starter

This lab environment is aligned with the **Git Rebase Skill Framework**.  
It sets up a small Git repo with `main` and `feature` branches for practicing rebasing.

---

## 🚀 Quick Start

```bash
unzip lab-starter.zip
cd lab-starter

make up       # Bootstrap lab
make verify   # Check lab state
make reset    # Reset to baseline
```

---

## 🛠️ Makefile Commands

| Command       | Description                |
| ------------- | -------------------------- |
| `make up`     | Bootstrap labs             |
| `make verify` | Verify lab state           |
| `make reset`  | Reset labs to baseline     |
| `make clean`  | Remove labs directory only |
| `make reup`   | Clean + bootstrap fresh    |
| `make show`   | List workspace contents    |
| `make help`   | Show this help text        |

---

## 🔒 Notes

- Default lab root: `./labs` (override with `LAB_ROOT=/path make up`)
- No network required (all local fixtures).
- Repo contains:
  - `main` with 3 commits
  - `feature` diverging with 2 additional commits
