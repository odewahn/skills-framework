#!/usr/bin/env bash
set -euo pipefail

LAB_ROOT="${LAB_ROOT:-./labs}"
REPO_PATH="$LAB_ROOT/git-rebase-lab"

echo "🔍 Verifying lab state..."

if [ ! -d "$REPO_PATH/.git" ]; then
  echo "❌ Repo not found at $REPO_PATH"
  exit 1
fi

cd "$REPO_PATH"

# Ensure branches exist
if ! git show-ref --verify --quiet refs/heads/main; then
  echo "❌ Missing 'main' branch"
  exit 1
fi

if ! git show-ref --verify --quiet refs/heads/feature; then
  echo "❌ Missing 'feature' branch"
  exit 1
fi

# Ensure commit count baseline
MAIN_COUNT=$(git rev-list --count main)
FEATURE_COUNT=$(git rev-list --count feature)

if [ "$MAIN_COUNT" -lt 3 ]; then
  echo "❌ Expected ≥3 commits on main, got $MAIN_COUNT"
  exit 1
fi

if [ "$FEATURE_COUNT" -lt 5 ]; then
  echo "❌ Expected ≥5 commits on feature (including main), got $FEATURE_COUNT"
  exit 1
fi

echo "✅ Verification passed."
