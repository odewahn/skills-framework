#!/usr/bin/env bash
set -euo pipefail

LAB_ROOT="${LAB_ROOT:-./labs}"
REPO_PATH="$LAB_ROOT/git-rebase-lab"

echo "🚀 Bootstrapping lab at $REPO_PATH..."

# Reset if exists
rm -rf "$REPO_PATH"
mkdir -p "$LAB_ROOT"
cd "$LAB_ROOT"

# Init repo
git init git-rebase-lab
cd git-rebase-lab

# Create main branch with 3 commits
git checkout -b main
echo "base1" > file.txt
git add file.txt && git commit -m "base commit 1"
echo "base2" >> file.txt
git commit -am "base commit 2"
echo "base3" >> file.txt
git commit -am "base commit 3"

# Create feature branch with 2 commits diverging
git checkout -b feature
echo "feature1" >> file.txt
git commit -am "feature commit 1"
echo "feature2" >> file.txt
git commit -am "feature commit 2"

echo "✅ Bootstrap complete."
