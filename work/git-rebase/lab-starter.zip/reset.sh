#!/usr/bin/env bash
set -euo pipefail

LAB_ROOT="${LAB_ROOT:-./labs}"

echo "🧹 Resetting lab..."
rm -rf "$LAB_ROOT/git-rebase-lab"

# Re-run bootstrap
"./bootstrap.sh"

echo "✅ Reset complete."
